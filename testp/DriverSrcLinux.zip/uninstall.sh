	rm -f /dev/MSRdrv
	rmmod MSRdrv
