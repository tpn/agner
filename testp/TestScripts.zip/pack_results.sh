#!/bin/bash
# alltests.sh                                            2013-08-07 Agner Fog
# (c) Copyright 2013 by Agner Fog. GNU General Public License www.gnu.org/licenses

# pack all results into zipfile
zip -q allresults.zip results1/* results2/*
